import boto3
import datetime
import os

# Initialize clients
rds = boto3.client('rds')
sns = boto3.client('sns')

# Environment variables
RDS_INSTANCE_IDENTIFIER = os.getenv('RDS_INSTANCE_IDENTIFIER')  # Set in Lambda environment
SNS_TOPIC_ARN = os.getenv('SNS_TOPIC_ARN')  # Set in Lambda environment

def lambda_handler(event, context):
    # Define the time range for the previous calendar day
    today = datetime.date.today()
    start_time = today + datetime.timedelta(days=100)
    end_time = today

    # Get all snapshots for the RDS instance
    try:
        response = rds.describe_db_snapshots(
            DBInstanceIdentifier=RDS_INSTANCE_IDENTIFIER,
            SnapshotType='automated'
        )
    except Exception as e:
        print(f"Error fetching snapshots: {e}")
        return

    # Filter for snapshots created within the previous calendar day
    backup_found = False
    for snapshot in response['DBSnapshots']:
        snapshot_time = snapshot['SnapshotCreateTime'].date()
        if start_time <= snapshot_time < end_time:
            backup_found = True
            alert_message = f"Backup snapshot found: {snapshot['DBSnapshotIdentifier']} created on {snapshot['SnapshotCreateTime']}"
            print(alert_message)
            
            # Publish to SNS and confirm delivery
            response = sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject="RDS Backup Found",
                Message=alert_message
            )
            print(f"SNS message sent successfully, MessageId: {response['MessageId']}")
            break

    # Send alert if no backup was found within the previous calendar day
    if not backup_found:
        alert_message = f"No successful backup found for {RDS_INSTANCE_IDENTIFIER} on {start_time.isoformat()}"
        print(alert_message)
        
        # Publish to SNS and confirm delivery
        response = sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject="RDS Backup Alert",
            Message=alert_message
        )
        print(f"SNS message sent successfully, No Backup Found! MessageId: {response['MessageId']}")

    return {
        "statusCode": 200,
        "backup_found": backup_found,
        "message": "Backup check completed"
    }
